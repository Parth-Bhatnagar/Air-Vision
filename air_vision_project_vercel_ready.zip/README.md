

## Vercel Deployment (Frontend + Serverless API)

This repo is prepared for Vercel deployment (single-click). It includes serverless API routes under `/api/*`.

Steps:
1. Create a GitHub repository and push this project.
2. Sign up at https://vercel.com and import the GitHub repo.
3. In the Vercel project settings, add Environment Variables:
   - `EARTHDATA_USERNAME` (for TEMPO worker, optional)
   - `EARTHDATA_PASSWORD` (for TEMPO worker, optional)
   - `NASA_API_KEY` (optional)
   - `OPENWEATHER_KEY` (optional, if you use OpenWeather geocoding)
4. Deploy. Vercel will host the static frontend and the serverless functions.

Notes:
- The TEMPO data endpoints (`/api/tempo/no2`, `/api/tempo/clouds`) serve preprocessed JSON files from `server/tempo_data`. To generate real TEMPO data, run the Python worker in `server/tempo_worker/fetch_tempo.py` after configuring Earthdata credentials.
