const fs = require('fs');
const path = require('path');

module.exports = async (req, res) => {
  try {
    const file = path.join(__dirname, '..', 'server', 'tempo_data', 'no2_latest.json');
    if (fs.existsSync(file)) {
      const data = fs.readFileSync(file, 'utf8');
      res.setHeader('Content-Type', 'application/json');
      return res.status(200).send(data);
    } else {
      return res.status(404).json({ error: 'NO2 data not generated. Run tempo worker.'});
    }
  } catch (err) {
    console.error('Tempo NO2 error', err);
    return res.status(500).json({ error: err.message });
  }
};
