const fetch = require('node-fetch');

module.exports = async (req, res) => {
  try {
    const { lat, lon } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'lat and lon required' });
    const url = `https://api.open-elevation.com/api/v1/lookup?locations=${lat},${lon}`;
    const r = await fetch(url);
    if (!r.ok) return res.status(502).json({ error: 'Elevation fetch failed', status: r.status });
    const data = await r.json();
    res.setHeader('Content-Type', 'application/json');
    return res.status(200).send(data);
  } catch (err) {
    console.error('Elevation API error', err);
    return res.status(500).json({ error: err.message });
  }
};
