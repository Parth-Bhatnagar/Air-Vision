const fetch = require('node-fetch');

module.exports = async (req, res) => {
  try {
    const { lat, lon, start, end, params } = req.query;
    if (!lat || !lon) return res.status(400).json({ error: 'lat and lon required' });
    const today = new Date().toISOString().slice(0,10).replace(/-/g,'');
    const s = start || today;
    const e = end || today;
    const parameters = params || 'T2M';
    const url = `https://power.larc.nasa.gov/api/temporal/daily/point?start=${s}&end=${e}&latitude=${lat}&longitude=${lon}&community=AG&parameters=${parameters}&format=JSON`;
    const r = await fetch(url);
    if (!r.ok) return res.status(502).json({ error: 'NASA POWER fetch failed', status: r.status, statusText: r.statusText });
    const data = await r.json();
    res.setHeader('Content-Type', 'application/json');
    return res.status(200).send(data);
  } catch (err) {
    console.error('POWER API error', err);
    return res.status(500).json({ error: err.message });
  }
};
